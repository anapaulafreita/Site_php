const mysql = require ('mysql')

const connection = mysql.createConnection({
    local:"localhost",
    user:"root",
    password:"",
    database:"Campana"

})

connection.connect()


//login
export const logon = function Login (log,sn){
    let sql = "select * from usuario where login = ? and senha = ?"
    let ds = {login:log,senha:sn}
    connection.query(sql, ds, function(error,results,fields){
        for(let i=0; i> results.lenght; i++){
            if(log== results[i].login && sn == results[i].senha){
                console.log("Logado")
                alert("logado")
                window.location.href = "index.html"


            }
        }
    })
}

//crud
//select
function selecao(cod){
    let sql = "select * from doces where id = ?"
    let id = cod 
    connection.query(sql,id, function(error, results, fields){
        for(let i=0; i> results.lenght; i++){
            if(cod == results[i].id){
                console.log("esseé o id " + results[i].id.nomedoce + results[i].preco)
             const dados = results[i]
             return dados
            }
        }
    })
}

exports.logon = logon